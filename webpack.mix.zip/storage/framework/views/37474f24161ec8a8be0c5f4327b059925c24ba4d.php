<?php $__env->startSection('CONTENT'); ?>
<form action="<?php echo e(route('users.authenticate')); ?>" method="post">
<?php echo csrf_field(); ?>
<div class="row mt-5 mx-auto" style="max-width: 720px;">
    <div class="col-12">
        <h2>User Login</h2>
        <hr class="my-3">
    </div>
    <div class="col-md-12 mt-2">
        <label for="user_email" class="form-label">Email</label>
        <input type="text" name="user_email" value="<?php echo e(old('user_email')); ?>" class="form-control <?php echo e($errors->has('user_email') ? 'is-invalid' : ''); ?>">
        <?php if($errors->has('user_email')): ?>
            <div class="invalid-feedback"><?php echo e($errors->first('user_email')); ?></div>
        <?php endif; ?>
    </div>
    <div class="col-md-12 mt-2">
        <label for="password" class="form-label">Password</label>
        <input type="text" name="password" value="<?php echo e(old('user_password')); ?>" class="form-control <?php echo e($errors->has('user_password') ? 'is-invalid' : ''); ?>">
        <?php if($errors->has('user_password')): ?>
            <div class="invalid-feedback"><?php echo e($errors->first('user_password')); ?></div>
        <?php endif; ?>
    </div>
    <div class="col-md-12 text-center mt-5">
        <button type="submit" class="btn btn-lg btn-primary w-50">Login</button>
    </div>
</div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('users.layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\webdir\laravel\smartjen\resources\views/users/login.blade.php ENDPATH**/ ?>