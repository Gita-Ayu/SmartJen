<?php $__env->startSection('CONTENT'); ?>
<form action="<?php echo e(route('admin.register')); ?>" method="post">
<?php echo csrf_field(); ?>
<div class="row mt-5 mx-auto" style="max-width: 720px;">
    <div class="col-12">
        <h2>School Signup</h2>
        <hr class="my-3">
    </div>
    <div class="col-md-6 mt-2">
        <label for="school_name" class="form-label">School name</label>
        <input type="text" name="school_name" value="<?php echo e(old('school_name')); ?>" class="form-control <?php echo e($errors->has('school_name') ? 'is-invalid' : ''); ?>">
        <?php if($errors->has('school_name')): ?>
            <div class="invalid-feedback"><?php echo e($errors->first('school_name')); ?></div>
        <?php endif; ?>
    </div>
    <div class="col-md-6 mt-2">
        <label for="email" class="form-label">Email</label>
        <input type="text" name="email" value="<?php echo e(old('email')); ?>" class="form-control <?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>">
        <?php if($errors->has('email')): ?>
            <div class="invalid-feedback"><?php echo e($errors->first('email')); ?></div>
        <?php endif; ?>
    </div>
    <div class="col-md-12 mt-2">
        <label for="password" class="form-label">Password</label>
        <input type="text" name="password" value="<?php echo e(old('password')); ?>" class="form-control <?php echo e($errors->has('password') ? 'is-invalid' : ''); ?>">
        <label for="password" class="form-label text-center">Minimum 8 characters and must include one character each for capital, small and special character</label>
        <?php if($errors->has('password')): ?>
            <div class="invalid-feedback"><?php echo e($errors->first('password')); ?></div>
        <?php endif; ?>
    </div>
    <div class="col-md-12 text-center mt-5">
        <button type="submit" class="btn btn-lg btn-primary w-50">Signup</button>
    </div>
</div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\webdir\laravel\smartjen\resources\views/admin-signup.blade.php ENDPATH**/ ?>