<?php $__env->startSection('CONTENT'); ?>
<?php if(auth()->guard('school')->check()): ?>
    <h3><strong><?php echo e(Auth::guard('school')->user()->school_name); ?></strong></h3>
<?php endif; ?>
    <hr>
    <div class="container">
        <div class="row">
            <div class="col-md-6 mb-5">
                <h4>Teachers</h4>
                <hr>
                <div style="max-width: 360px">
                    <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="d-flex py-2 border-bottom"><?php echo e($teacher->user_name); ?>

                            <div class="ms-auto">
                                <button type="submit" onclick="window.location.href='<?php echo e(route('admin.user.edit')); ?>/<?php echo e($teacher->user_id); ?>'" class="btn btn-primary btn-sm">Edit</button>
                                <button type="submit" onclick="window.location.href='<?php echo e(route('admin.user.chat')); ?>/<?php echo e($teacher->user_id); ?>'"class="btn btn-success btn-sm">Chat</button>
                                <button type="submit" onclick="deleteConfirm('<?php echo e(route('admin.user.delete')); ?>/<?php echo e($teacher->user_id); ?>','<?php echo e($teacher->user_name); ?>')" class="btn btn-danger btn-sm">Delete</button>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="col-md-6 mb-5">
                <h4>Students</h4>
                <hr>
                <div style="max-width: 360px">
                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="d-flex py-2 border-bottom"><?php echo e($student->user_name); ?>

                        <div class="ms-auto" style="max-width: 300px;">
                            <button type="submit" onclick="window.location.href='<?php echo e(route('admin.user.edit')); ?>/<?php echo e($student->user_id); ?>'" class="btn btn-primary btn-sm">Edit</button>
                            <button type="submit" onclick="deleteConfirm('<?php echo e(route('admin.user.delete')); ?>/<?php echo e($student->user_id); ?>','<?php echo e($student->user_name); ?>')" class="btn btn-danger btn-sm">Delete</button>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\webdir\laravel\smartjen\resources\views/admin/home.blade.php ENDPATH**/ ?>