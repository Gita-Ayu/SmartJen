<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="N/A">
    <meta name="generator" content="Laravel 8.5">
    <title><?php if(isset($title)): ?><?php echo e($title.' | SmartJen'); ?> <?php else: ?> <?php echo e('SmartJen'); ?><?php endif; ?></title>
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
</head>
<body class="bg-light">
<header class="p-3 bg-primary text-white">
    <div class="container">
        <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start">
            <a href="<?php echo e(route('web.home')); ?>" class="d-flex align-items-center mb-2 mb-lg-0 text-white text-decoration-none">
                <h2 class="pr-xl-2">Smartjen</h2>
            </a>
            <ul class="nav col-12 col-lg-auto me-lg-auto mb-2 justify-content-center mb-md-0">
                <li><a href="<?php echo e(route('admin.home')); ?>" class="nav-link px-2 text-white">Dashboard</a></li>
                <li><a href="<?php echo e(route('admin.user.invitation')); ?>" class="nav-link px-2 text-white">Invite User</a></li>
            </ul>
            <?php if(auth()->guard('school')->check()): ?>
            <div class="text-end">
                <a href="<?php echo e(route('admin.logout')); ?>">
                    <button type="button" class="btn btn-outline-light me-2">LOGOUT</button>
                </a>
            </div>
            <?php endif; ?>
            <?php if(auth()->guard('school')->guest()): ?>
            <div class="text-end">
                <a href="<?php echo e(route('admin.login')); ?>">
                    <button type="button" class="btn btn-outline-light me-2">LOGIN</button>
                </a>
                <a href="<?php echo e(route('admin.signup')); ?>">
                    <button type="button" class="btn btn-warning">SIGN-UP</button>
                </a>
            </div>
            <?php endif; ?>
        </div>
    </div>
</header>
<div class="container py-5" style="min-height: 80vh; ">
<!-- CONTENT -->
<?php echo $__env->yieldContent('CONTENT'); ?>
<!-- CONTENT -->
</div>
<div class="bg-black text-white">
<footer class="text-center text-small py-5">
    <p class="mb-1">&copy; 2021 SmartJen</p>
</footer>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/scripts.js')); ?>"></script>
</body>
</html>
<?php /**PATH E:\webdir\laravel\smartjen\resources\views/admin/layouts/template.blade.php ENDPATH**/ ?>