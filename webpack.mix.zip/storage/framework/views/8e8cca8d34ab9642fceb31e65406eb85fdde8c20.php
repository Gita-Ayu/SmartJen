<?php $__env->startSection('CONTENT'); ?>
<h3 class="text-center" style="margin-top: 30vh;"><?php echo e(session('message')); ?></h3>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\webdir\laravel\smartjen\resources\views/admin-message.blade.php ENDPATH**/ ?>