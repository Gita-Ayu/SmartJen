<?php $__env->startSection('CONTENT'); ?>
<?php if(auth()->guard('users')->check()): ?>
    <h3><strong>Welcome Back <?php echo e(Auth::guard('users')->user()->user_name); ?>!</strong></h3>
    <h5 class="mt-3">School: <?php echo e(ucwords($school->school_name)); ?></h5>
    <h5>Status: <?php echo e(ucwords(Auth::guard('users')->user()->user_role)); ?></h5>
    <hr>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('users.layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\webdir\laravel\smartjen\resources\views/users/home.blade.php ENDPATH**/ ?>