<?php $__env->startComponent('mail::message'); ?>
# Smart Jen Invitation
***
Hi __<?php echo e($data['user_name']); ?>__!

We are happy to invite you to join us as a <?php echo e($data['user_role']); ?> at our school __<?php echo e($data['school_name']); ?>__.

You can login to your account and start using it.
Your credentials are as follow:

Email:<br>
__<?php echo e($data['user_email']); ?>__

Password:<br>
__<?php echo e($data['unhashed']); ?>__

Click the button to login.
<?php $__env->startComponent('mail::button', ['url' => $data['url'],'color' => 'success']); ?>
Login
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e($data['school_name']); ?> Admin.
<?php echo $__env->renderComponent(); ?>
<?php /**PATH E:\webdir\laravel\smartjen\resources\views/emails/invitation.blade.php ENDPATH**/ ?>