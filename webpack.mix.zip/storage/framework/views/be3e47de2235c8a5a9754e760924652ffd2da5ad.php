<?php echo e($slot); ?>

<?php /**PATH E:\webdir\laravel\smartjen\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>