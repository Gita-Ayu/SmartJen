<?php $__env->startSection('CONTENT'); ?>
<form action="<?php echo e(route('admin.invite.register')); ?>" method="post">
<?php echo csrf_field(); ?>
<div class="row mt-5 mx-auto" style="max-width: 720px;">
    <div class="col-12">
        <h2>Invite User</h2>
        <hr class="my-3">
    </div>
    <div class="col-md-6 mt-2">
        <label for="user_name" class="form-label">Invitee Name</label>
        <input type="text" name="user_name" value="<?php echo e(old('user_name')); ?>" class="form-control <?php echo e($errors->has('user_name') ? 'is-invalid' : ''); ?>">
        <?php if($errors->has('user_name')): ?>
            <div class="invalid-feedback"><?php echo e($errors->first('user_name')); ?></div>
        <?php endif; ?>
    </div>
    <div class="col-md-6 mt-2">
        <label for="user_email" class="form-label">invitee Email</label>
        <input type="text" name="user_email" value="<?php echo e(old('user_email')); ?>" class="form-control <?php echo e($errors->has('user_email') ? 'is-invalid' : ''); ?>">
        <?php if($errors->has('user_email')): ?>
            <div class="invalid-feedback"><?php echo e($errors->first('user_email')); ?></div>
        <?php endif; ?>
    </div>
    <div class="col-md-12 mt-2">
        <label for="user_role" class="form-label">Invitee Role</label>
        <select name="user_role" class="form-control">
            <option value="teacher" selected>Teacher</option>
            <option value="student">Student</option>
        </select>
        <?php if($errors->has('user_role')): ?>
            <div class="invalid-feedback"><?php echo e($errors->first('user_role')); ?></div>
        <?php endif; ?>
    </div>
    <div class="col-md-12 text-center mt-5">
        <button type="submit" class="btn btn-lg btn-primary w-50">Signup</button>
    </div>
</div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\webdir\laravel\smartjen\resources\views/admin/invitation_form.blade.php ENDPATH**/ ?>