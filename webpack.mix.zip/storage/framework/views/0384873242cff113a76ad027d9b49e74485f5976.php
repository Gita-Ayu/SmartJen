<?php $__env->startSection('CONTENT'); ?>
<h3 class="text-center" style="margin-top: 30vh;"><?php echo e(session('message')); ?></h3>
    <div class="text-center">
        <a href="<?php echo e(route('admin.home')); ?>">
            <button type="submit" class="btn btn-primary">Home</button>
        </a>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\webdir\laravel\smartjen\resources\views/admin/message.blade.php ENDPATH**/ ?>