<tr>
<td class="header">
<a href="<?php echo e($url); ?>" style="display: inline-block;">
<?php if(trim($slot) === 'Laravel'): ?>
<img src="https://static-contents-smartjen.s3.ap-southeast-1.amazonaws.com/img/smart-jen-logo-horizontal-v3.png" width="570" alt="Smart Jen Logo">
<?php else: ?>
<?php echo e($slot); ?>

<?php endif; ?>
</a>
</td>
</tr>
<?php /**PATH E:\webdir\laravel\smartjen\resources\views/vendor/mail/html/header.blade.php ENDPATH**/ ?>