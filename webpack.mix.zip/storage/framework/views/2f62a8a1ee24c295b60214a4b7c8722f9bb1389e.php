<?php $__env->startSection('CONTENT'); ?>
<h3 class="text-center" style="margin-top: 30vh;"><?php echo e(session('message')); ?></h3>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('users.layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\webdir\laravel\smartjen\resources\views/users/message.blade.php ENDPATH**/ ?>