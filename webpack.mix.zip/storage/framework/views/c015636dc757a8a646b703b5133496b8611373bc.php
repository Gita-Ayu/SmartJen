<?php $__env->startSection('CONTENT'); ?>
<h2>School Sign-up</h2>
<div class="row mt-5">
    <div class="col-md-6">
        <label for="school_name" class="form-label">School Name</label>
        <input type="text" name="school_name" class="form-control">
    </div>
    <div class="col-md-6">
        <label for="email" class="form-label">Email</label>
        <input type="text" name="school_name" class="form-control">
    </div>
    <div class="col-md-12">
        <label for="password" class="form-label">Password</label>
        <input type="password" name="school_name" class="form-control">
    </div>
    <div class="col-md-12 text-center mt-5">
        <button type="button" class="btn btn-lg btn-primary w-50">Signup</button>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\webdir\laravel\smartjen\resources\views/admin-register.blade.php ENDPATH**/ ?>