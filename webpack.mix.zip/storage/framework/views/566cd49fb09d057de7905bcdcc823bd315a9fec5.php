
<?php $__env->startSection('CONTENT'); ?>
    <div class="row">
        <div class="col-12">
            <h3>Welcome to Smartjen</h3>
            <hr>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\webdir\laravel\smartjen\resources\views/home.blade.php ENDPATH**/ ?>