@extends('layouts.template')
@section('CONTENT')
    <div class="row">
        <div class="col-12">
            <h3>Welcome to Smartjen</h3>
            <hr>
        </div>
    </div>
@endsection