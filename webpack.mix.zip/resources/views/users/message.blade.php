@extends('users.layouts.template')
@section('CONTENT')
<h3 class="text-center" style="margin-top: 30vh;">{{session('message')}}</h3>
@endsection